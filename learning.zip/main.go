package main

func handleHome(c echo.Context) error {
	// return c.String(http.StatusOK, "Hello, World!")
	return c.File("home.html")
}

const fileName string = "jobs.csv"

func handleScrape(c echo.Context) error {
	defer os.Remove(FILE_NAME) // 다운로드 후 server에 존재하는 jobs.csv 파일 제거
	// term 값 가져오고 검색어는 초기화하고 lower case 해줌
	term := strings.ToLower(scrapper.CleanString(c.ForValue("term")))
	scrapper.Scrape(term)

	// 첨부파일 Return(return할 파일, 사용자에게 전달할 파일이름)
	// 파일은 서버에 저장되고, web에서 다운받을 수 있음
	return c.Attachment("jobs.csv", "jobs.csv")
}

// echo.labstack.com/guide 참고
// 추가 공부 시 gobuffalo 공부해보기 , gobuffalo.io
// go.mod : https://aidanbae.github.io/code/golang/modules/
func main() {
	//go get github.com/labstack/echo 명령으로 echo 설치
	// scrapper.Scrape("term")

	e := echo.New()
	e.Get("/", handleHome)           // Default View
	e.POST("/scrape", handleScrape)  // Post로 /scrape URL 매핑정보가 넘어오면 handleScrape 호출
	e.Logger.Fatal(e.Start(":1323")) // 1323포트, localhost:1323
}
