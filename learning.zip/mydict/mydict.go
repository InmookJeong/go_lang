package mydict

import "errors"

// Dictionary is like alias.
// Dictionary is not Structure. this is alias for a map[string]string.
// type에 대한 alias 생성
// Dictionary는 map[string]string을 다르게 뜻하는 의미일 뿐.
// Dictionary type
type Dictionary map[string]string

// type도 struct처럼 method를 정의할 수 있음
var (
	errorNotFound   = errors.New("Not found")
	errorWordExists = errors.New("That word aleady exists")
)

// search method
// 찾는 결과가 없으면 error return
func (d Dictionary) Search(word string) (string, error) {
	// Map에 word에 해당하는 key 존재 여부 체크, key가 있으면 value에 값 저장, 존재 여부에 따라 exist는 boolean 값을 갖게 됨
	value, exists := d[word]
	if exists {
		// error == null
		return value, nil
	}
	return "", errorNotFound
}

// Add a word to the dictionary
// 파라미터로 받는 word와 definition이 둘다 string type이므로 한번만 작성
func (d Dictionary) Add(word, def string) error {
	// 값은 필요없은이까 _로 작성해서 무시하도록 처리
	_, err := d.Search(word)
	switch err {
	case errorNotFound:
		d[word] = def
	case nil:
		return errorWordExists
	}

	return nil
}

// Updatee a word to the dictionary
func (d Dictionary) Update(word, def string) error {
	_, err := d.Search(word)
	switch err {
	case errorNotFound:
		return errorNotFound
	case nil:
		d[word] = def
	}

	return nil
}

// Delete a word to the dictionary
func (d Dictionary) Delete(word string) {
	delete(d, word)
}
