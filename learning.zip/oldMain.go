package main

import (
	"encoding/csv"
	"errors"
	"fmt"
	"log"
	"net/http"
	"os"
	"strconv"
	"strings"
	"time"

	"github.com/learning/accounts"
	"github.com/learning/mydict"
)

// Create struct
type person struct {
	name    string
	age     int
	favFood []string
}

// java : constructor()
// python : __init__
// Go에는 해당 기능 없음 -> constructor나 Method나 동등하게 인식
// channels and go routines는 미니프로젝트 하면서 학습

// func func_name, func_parameter, return type
// golang 참고 사이트 : https://blog.golang.org/
/*
PS. 여러 줄 주석은 type, struct에게 적용이 안됨
func이나 func 안에서 사용 가능
*/
func oldMain() {
	fmt.Println("Hello World...!")

	/* something.SayHello()
	something.SayBye()
	*/

	const constName string = "mook(const)"
	fmt.Println(constName)

	// var name string = "mook"
	name := "mook" // 축약형은 func 안에서만 사용 가능
	fmt.Println(name)

	fmt.Println("-------------------")
	fmt.Println(multiply(2, 2))

	// 변수 하나만 만들어주면 error 발생
	// totalLength, _로 변수들 선언해주면 하나만 리턴 받는거 가능
	// _가 변수를 무시해주는 역할
	totalLength, upperName := lenAndUpper("mook")
	fmt.Println(totalLength, upperName)

	fmt.Println("mook", "jim", "james", "inmook")

	fmt.Println(lenAndUpper2("mooka"))

	total := loopFunc(1, 2, 3, 4, 5, 6)
	fmt.Println(total)

	fmt.Println(canIDrink(16))

	fmt.Println(canIDrink2(18))

	fmt.Println(canIDrink3(18))

	// Pointer
	a := 2
	b := a
	a = 10
	// &을 붙이면 메모리 주소 확인 가능
	fmt.Println(a, b)
	fmt.Println(&a, &b)

	aa := 2
	bb := &aa // aa의 주소 참조
	aa = 7
	fmt.Println(aa, bb, *bb) // *은 참조된 메모리의 값을 열람
	*bb = 10                 // 참조된 주소의 값을 수정할 수 있음
	fmt.Println(aa, *bb)

	// Array
	names := [5]string{"nico", "lynn", "dal"}
	names[3] = "alala3"
	names[4] = "alala4"
	fmt.Println("names -> ", names)

	// non length Array
	names2 := []string{"nico", "lynn", "dal"}
	// names2[3] = "alala3"		--> intext out of range Error
	// slice(=첫번째 파라미터)에 value(두번째 파라미터)를 추가해서 새로운 slice를 Return
	names2 = append(names2, "alala-3")
	names2 = append(names2, "alala-4")
	names2 = append(names2, "alala-5")
	names2 = append(names2, "alala-6")
	fmt.Println("names2 --> ", names2)

	// map[key]value{key:value, ---}
	sampleMap := map[string]string{"name": "nico", "age": "20"}
	fmt.Println(sampleMap)
	for key, value := range sampleMap {
		fmt.Println(key, " : ", value)
	}
	fmt.Println(sampleMap["name"])
	sampleMap["nation"] = "Korea"
	fmt.Println("map --> ", sampleMap)
	// delete map
	delete(sampleMap, "nation")
	fmt.Println("map --> ", sampleMap)
	// key check
	val, exists := sampleMap["age"]
	fmt.Println(val, " exists : ", exists)
	val2, exists2 := sampleMap["nation"]
	fmt.Println(val2, " exists : ", exists2)
	if !exists2 {
		println("no....")
	}

	// struct --> structure(구조체), 일종의 Object Type Data or Class
	favFood := []string{"test", "sample"}
	sampleStruct := person{name: "nico", age: 29, favFood: favFood}
	fmt.Println(sampleStruct)
	fmt.Println(sampleStruct.age)

	// create account
	fmt.Println("---Account Test---")
	account := accounts.NewAccount("mook")
	fmt.Println(account)
	account.Deposit(10)
	fmt.Println(account.Balance())
	err := account.Withdraw(20)
	if err != nil {
		// Fatalln은 실행 후 프로그램 종료시킴
		// log.Fatalln(err)
		fmt.Println(err)
	}
	fmt.Println(account.Balance())
	fmt.Println(account.Balance(), account.Owner())
	fmt.Println(account) // account.go에 작성된 String()의 return을 출력, String()은 structure를 string 형태로 가져오도록 go에서 지원하는 Method

	// ----- Dictionary -----

	// Create empty dictionary
	dictionary := mydict.Dictionary{}
	dictionary["hello"] = "hello"
	fmt.Println(dictionary)
	dictionary = mydict.Dictionary{"first": "First Word"} // Search Test
	fmt.Println(dictionary["first"])
	definition, err := dictionary.Search("second") // dictionary.Search("first")
	if err != nil {
		fmt.Println(err)
	} else {
		fmt.Println(definition)
	}
	// Add Dictionary
	addErr := dictionary.Add("hello", "Greeting")
	if addErr == nil {
		fmt.Println("Add Result : ", dictionary)
	} else {
		fmt.Println("Add Result : ", addErr)
	}
	addErr2 := dictionary.Add("first", "Wow")
	if addErr2 == nil {
		fmt.Println("Add Result : ", dictionary)
	} else {
		fmt.Println("Add Result : ", addErr2)
	}

	// Update Dictionary
	updateErr := dictionary.Update("hello", "OMG")
	updateDictionaryResult(dictionary, "hello", updateErr)
	updateErr = dictionary.Update("AA", "aa")
	updateDictionaryResult(dictionary, "AA", updateErr)

	// Delete Dictionary
	_, de := dictionary.Search("hello")
	if de != nil {
		fmt.Println("hello", de)
	} else {
		dictionary.Delete("hello")
		fmt.Println("delete hello")
		fmt.Println(dictionary)
	}

	_, de = dictionary.Search("aa")
	if de != nil {
		fmt.Println("aa", de)
	} else {
		dictionary.Delete("aa")
		fmt.Println("delete aa")
		fmt.Println(dictionary)
	}

	/* URL Checker */
	urls := []string{
		"https://www.google.com/",
		"https://www.reddit.com",
		"https://www.instagram.com/",
		"https://academy.nomadcoders.co/",
	}

	// var urlCheckResults = map[string]string		--> 초기화 하지 않은 맵은 실행 시 에러처리 됨, map == nil
	/// var urlCheckResults = map[string]string{}	--> 맨 뒤에 {}를 붙여서 빈 값으로 초기화, 사용 가능
	var urlCheckResults = make(map[string]string) // --> 두번째 방법과 동일한 역할을 make함수가 해줌
	fmt.Println(urlCheckResults)
	// index, value
	for _, url := range urls {
		// fmt.Println(url)
		result := "OK"
		err := hitURL(url)
		if err != nil {
			result = "FAILED"
		}
		urlCheckResults[url] = result
	}
	// fmt.Println(urlCheckResults)
	for url, result := range urlCheckResults {
		fmt.Println(url, result)
	}

	// goroutines : 다른 함수와 동시에 실행시키는 함수
	// 그냥 함수를 실행하면 Top-Down 방식, 함수 앞에 go를 붙여 goroutines 기능으로 함수 실행
	go sexyCount("nico")
	sexyCount("Allice") // 여기에도 go를 붙이면 첫번째 goroutine 실행, 두밴쩌 goroutine 실행 후 매인함수 종료, 두 함수는 실행되지 않음.
	// main 함수가 종료되면 goroutines도 종료
	go sexyCount("nico")
	go sexyCount("Allice")
	time.Sleep(time.Second * 5) // 위에 함수가 모두 goroutine이기 때문에 5초 동안만 실행되고 main함수 종료

	// Channel
	// 1. goroutine이랑 main 함수 사이에 정보를 전달하기 위한 방법
	// 2. goroutine에서 다른 goroutine으로 커뮤니케이션 하는 역할
	// 즉, 파이프 역할
	fmt.Println("Channel Test......")
	c := make(chan string) // cannel을 통해 송수신 할 데이터 타입을 구체적으로 정해줘야 함
	people := [2]string{"nico", "flynn"}
	for _, person := range people {
		go isSexy(person, c)
	}
	// main 함수는 channel을 통해 메시지 받을 때까지 대기 -> 즉, Sleep 함수가 없어도 됨
	// channelResult := <-c
	// fmt.Println(channelResult)
	fmt.Println("Waiting for Messages....")
	fmt.Println(<-c) // Breaking Operation : 작업이 끝날 때 까지 멈추는 부분
	fmt.Println(<-c) // 여러개의 메시지를 받아야 되면 그 갯수에 맞게 채널 메시지를 받으면 됨, GoLnag이 goroutine보다 많은 채널 메시지를 받으려 하면 에러 출력해줌
	fmt.Println(".......")
	for _, person := range people {
		go isSexy(person, c)
	}
	/*
		순서가 그때 그때 다른 이유 : Concurrency(동시성) 때문
	*/
	for i := 0; i < len(people); i++ {
		// 배열 길이가 동적으로 늘어날 때 채널 메시지도 배열 수 만큼 for문을 활용하여 수신
		fmt.Println(<-c) // received channel msg
	}

	// goroutine을 활용한 URL Checker
	urlChannel := make(chan urlResult)
	for _, url := range urls {
		go hitURL2(url, urlChannel)
	}

	urlCheckResults2 := make(map[string]string)
	fmt.Println("URL Checker Wating...")
	for i := 0; i < len(urls); i++ {
		result := <-urlChannel
		urlCheckResults2[result.url] = result.status
	}

	for url, status := range urlCheckResults2 {
		fmt.Println("URL Checker -> ", url, status)
	}

	/* Job Scrapper */
	// goquery : jQuery와 같은 역할, HTML 내부를 들여다볼 수 있게 기능 제공
	// go get github.com/PuerkitoBio/goquery 명령어를 통해 goquery 설치
	// 모든 page의 jobs를 담을 배열 생성
	// var jobs []extractedJob
	// totalPages := getPages()
	/*
		for i:=0; i<totlaPages; i++ {
			extractedJobs := getPage(i)
			// jobs에 extractedJobs의 콘텐트를 추가
			// ... 안하면 배열 안에 배열이 추가되는 형태
			jobs.append(jobs, extractedJobs...)
		}

		writeJobs(jobs)
		fmt.Println("Done, extracted ", leng(jobs))
	*/

	/*
	위의 코드를 channel을 이용해서 작성
	c := make(chan []extractedJob)

	for i:=0; i<totlaPages; i++ {
		go getPage(i, c)
	}

	for i:=0; i<totlaPages; i++ {
		extractedJobs := <- c
		jobs.append(jobs, extractedJobs...)
	}
	writeJobs(jobs)
	fmt.Println("Done, extracted ", leng(jobs))
	*/

}

var baseURL string = "https://kr.indeed.com/jobs?q=python&limit=50"

type extractedJob struct {
	id       string
	title    string
	location string
	salary   string
	summary  string
}

/*
goquery 사용이 안되는 관계로 주석 처리
추후 사용 가능하면 테스트
*/

func writeJobs(jobs []extractedJob) {
	// 일자리를 CSV 파일로 저장 -> file name ; jobs.csv
	file, err := os.Create("jobs.csv")
	checkErr(err)

	w := csv.NewWriter(file)
	defer w.Flush()

	headers := []string{"ID", "Title", "Location", "Salary", "Summary"}

	wErr := w.Write(headers)
	checkErr(wErr)

	for _, job := range jobs {
		jobSlice := []string{job.id, job.title, job.location, job.salary, job.summary}
		jwErr := w.Write(jobSlice)
		checkErr(jwErr)
		// 이 부분이 끝나고 위에 defer w.Flush()가 실행
	}
}

func getPage(pageNum int, mainChan chan <- []extractedJob) {

	var jobs []extractedJob
	c := make(chan extractedJob)

	// strconv : string conversion
	pageURL := baseURL + "&start=" + strconv.Itoa(pageNum*50)
	fmt.Println("Requesting", pageURL)
	res, err := http.Get(pageURL)
	checkErr(err)
	checkResponseCode(res)

	defer res.Body.Close()

	doc, err := goquery.NewDocumentFromReader(res.Body)
	checkErr(err)

	searchCards := doc.Find(".jobsearch-SerpJobCard")
	searchCards.Each(func(i int, card *goquery.Selection) {
		go extractJob(card, c)
		// jobs = append(jobs, job)
	})

	for i:=0; i<searchCards.Length(); i++ {
		job: = <- c
		jobs = append(jobs, job)
	}

	mainChan <- jobs
}

func extractJob(card *goquery.Selection, c chan <- extractedJob) {
	// 존재 여부는 필요없으니까 _로 작성
	id, _ := card.Attr("data-jk")
	title := cleanString(card.Find(".title>a").Text())
	location := cleanString(card.Find(".sjcl").Text())
	salary := cleanString(card.Find(".salaryText").Text())
	summary := cleanString(card.Find(".summary").Text())

	// fmt.Println(id, title, location, salary, summary)
	c <- extractedJob{id: id, title: title, location: location, salary: salary, summary: summary}
}

func cleanString(str string) string {
	// strings 클래스의 TringSpace를 이용해서 개행문자 제거
	// strings.Fields는 모든 단어를 분리된 글자 배열로 만들어 줌
	// strings.Join은 문자 배열을 가져와서 합쳐줌 -> 공백을 구분자로 합침
	strFields := strings.Fields(strings.TrimSpace(str))
	return strings.Join(strFields, " ")
}

func getPages() int {
	pages := 0
	res, err := http.Get(baseURL)
	checkErr(err)
	checkResponseCode(res)
	// res.Body는 기본적으로 byte, I/O
	// 사용이 끝나면 defer를 통해 close해야 메모리 누수가 안생김
	defer res.Body.Close()

	// doc, err := goquery.NewDocumentFromReader(res.Body)
	// checkErr(err)
	fmt.Println("Doc stats check")
	// fmt.Println(doc)
	// Document에서 pagenation 클래스 찾기
	// doc.Find(".pagenation").Each(func(i int, s *goquery.Selection){
	// i : item
	// 	fmt.Println(s.Html()) // HTML(tag)
	//	pages = s.Find("a").Length() // a tag가 몇개 존재하는지 체크
	// })

	return pages
}

func checkErr(err error) {
	if err != nil {
		log.Fatalln(err)
	}
}

func checkResponseCode(res *http.Response) {
	if res.StatusCode != 200 {
		log.Fatalln("Request failed with Status : ", res.StatusCode)
	}
}

// ------------------------------------------------------------------------------------------------------------------------------------ */

// URL Checker에서 사용할 struct
type urlResult struct {
	url    string
	status string
}

// c chan string -> c : parameter, chan : parameter type, string : rerturn type
func isSexy(person string, c chan string) {
	time.Sleep(time.Second * 5)
	fmt.Println(person)
	c <- person + " is sexy" // send true
}

func sexyCount(person string) {
	for i := 0; i < 10; i++ {
		fmt.Println(person, "is sexy", i)
		time.Sleep(time.Second) // 1초 동안 sleep
	}
}

var errRequestFailed = errors.New("Request Failed.")

func hitURL2(url string, c chan<- urlResult) {
	// 함수 파라미터에 chan<-이라고 작성하면 이 채널은 보내기만 하는 기능(Send Only)이라는 의미 명시한것.
	// 여기서 <-c로 작성하면 이 함수 안에서는 channel을 보낼 수는 있고 받을 수는 없는 채널이라는 의미가 됨.
	resp, err := http.Get(url)
	status := "OK"
	if err != nil || resp.StatusCode >= 400 {
		status = "FAILED"
	}
	c <- urlResult{url: url, status: status}
}

func hitURL(url string) error {
	fmt.Println("Checking", url)
	resp, err := http.Get(url)
	if err != nil || resp.StatusCode >= 400 {
		fmt.Println(err, resp.StatusCode)
		return errRequestFailed
	}
	return nil
}

func updateDictionaryResult(dictionary mydict.Dictionary, key string, updateErr error) {
	if updateErr == nil {
		v, e := dictionary.Search("hello")
		if e == nil {
			fmt.Println(key, "update result : ", v)
		} else {
			fmt.Println(e)
		}
	} else {
		fmt.Println(updateErr)
	}
}

// return integer
func multiply(a, b int) int {
	return a * b
}

// multi return = integer, string
func lenAndUpper(name string) (int, string) {
	return len(name), strings.ToUpper(name)
}

func repeatMe(words ...string) {
	fmt.Print("repeatMe...")
	fmt.Println(words)
}

// naked return
func lenAndUpper2(name string) (length int, uppercase string) {
	// defer -> 현재 func이 값을 return한 다음에 실행
	defer fmt.Println("I'm done")
	fmt.Println("lenAndUpper2...")
	length = len(name)
	uppercase = strings.ToUpper(name)
	return
}

// loop는 for만 존재
// range -> array에 loop 적용, index와 value를 같이 줌
func loopFunc(numbers ...int) int {
	for index, number := range numbers {
		fmt.Println(index, number)
	}

	for i := 0; i < len(numbers); i++ {
		fmt.Println(numbers[i])
	}
	return 1
}

func canIDrink(age int) bool {
	fmt.Println("canIDring...")
	// if age < 20 {
	// variable expression 생성
	// koranAge를 block 안에서만 사용
	if koreanAge := age + 2; koreanAge < 20 {
		return false
	}
	return true
}

func canIDrink2(age int) bool {
	fmt.Println("canIDring2...")
	switch koreanAge := age + 2; koreanAge {
	case 10:
		return false
	case 18:
		return true
	}
	return false
}

func canIDrink3(age int) bool {
	fmt.Println("canIDring3...")
	switch {
	case age < 18:
		return false
	case age == 18:
		return true
	}
	return false
}
