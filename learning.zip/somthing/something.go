package something

import "fmt"

func SayHello() {
	fmt.Println("Hello")
}

func SayBye() {
	fmt.Println("Bye")
}
