package scrapper

import "fmt"

// 기존 main.go에서 crawl한 메소드를 여기에 넣기
// Scrape Indded by a term
func Scrape(term string) {
	// term : 검색어
	var baseURL string = "https://kr.indeed.com/jobs?q=" + term + "&limit=50"
	fmt.Println(baseURL)
}
