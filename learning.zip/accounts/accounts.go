package accounts

import (
	"errors"
	"fmt"
)

// Account struct
type Account struct {
	owner   string
	balance int
}

// NewAccount creates Account
func NewAccount(owner string) *Account {
	account := Account{owner: owner, balance: 0}
	fmt.Println("account addr : ", &account)
	fmt.Println("account val : ", *(&account))
	return &account
}

// a : reciever -> struct 이름 첫글자의 소문자
// *Account로 해야 실제 Account에 값이 반영
// Deposit x amout on your account
func (a *Account) Deposit(amount int) {
	a.balance += amount
}

// a Account -> Struct의 Account 복사본, 실제 Account가 아님
// Balance of your account
func (a Account) Balance() int {
	return a.balance
}

// Withdraw x amount from your account
// Error Handling
// return error
// GoLang에는 try-catch가 없음 - 직접 처리해줘야 함
func (a *Account) Withdraw(amount int) error {
	if a.balance < amount {
		return errors.New("Can not withdraw.")
	}
	a.balance -= amount
	// nil == null 역할
	return nil
}

// Change Owner of the account
func (a *Account) ChangeOwner(newOwner string) {
	a.owner = newOwner
}

// Owner of the account
func (a Account) Owner() string {
	return a.owner
}

func (a Account) String() string {
	// fmt.Sprint : string 형태
	return fmt.Sprint(a.Owner(), "'s account.\nHas : ", a.Balance())
}
